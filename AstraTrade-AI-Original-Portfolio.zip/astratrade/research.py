from __future__ import annotations
from dataclasses import dataclass
import itertools
import numpy as np
import pandas as pd
from .engine import BacktestConfig, run_backtest
from .strategies import StrategySpec, generate_signals

@dataclass(frozen=True)
class SweepRow:
    params: dict
    total_return: float
    sharpe: float
    max_drawdown: float


def parameter_sweep(df: pd.DataFrame, strategy: str, grid: dict[str, list], config: BacktestConfig) -> list[SweepRow]:
    keys = list(grid)
    results=[]
    for values in itertools.product(*(grid[k] for k in keys)):
        params=dict(zip(keys, values))
        signal=generate_signals(df, StrategySpec(strategy, params))
        _, _, metrics=run_backtest(df, signal, config)
        results.append(SweepRow(params, metrics["total_return"], metrics["sharpe"], metrics["max_drawdown"]))
    return sorted(results, key=lambda r: (r.sharpe, r.total_return), reverse=True)


def monte_carlo_trade_reshuffle(trades: pd.DataFrame, initial_capital: float = 100_000, iterations: int = 1000, seed: int = 7) -> dict:
    if trades.empty:
        return {"iterations": iterations, "median_final": initial_capital, "p05_final": initial_capital, "p95_final": initial_capital}
    rng=np.random.default_rng(seed)
    pnl=trades["pnl"].to_numpy(float)
    finals=np.empty(iterations)
    for i in range(iterations):
        finals[i]=initial_capital + rng.choice(pnl, size=len(pnl), replace=True).sum()
    return {"iterations": iterations, "median_final": float(np.median(finals)), "p05_final": float(np.quantile(finals, .05)), "p95_final": float(np.quantile(finals, .95))}


def research_brief(metrics: dict, benchmark_return: float, monte_carlo: dict | None = None) -> str:
    return (
        f"Backtest total return: {metrics['total_return']:.2%}. "
        f"CAGR: {metrics['cagr']:.2%}. Sharpe: {metrics['sharpe']:.2f}. "
        f"Maximum drawdown: {metrics['max_drawdown']:.2%}. "
        f"Benchmark return: {benchmark_return:.2%}. "
        "These are historical simulation results, not a forecast. "
        + (f"Trade-reshuffle median final equity: {monte_carlo['median_final']:.2f}." if monte_carlo else "")
    )
