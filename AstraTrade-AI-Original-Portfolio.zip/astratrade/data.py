from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import pandas as pd

REQUIRED = ["Open", "High", "Low", "Close", "Volume"]


@dataclass(frozen=True)
class ValidationResult:
    rows: int
    start: str
    end: str
    warnings: tuple[str, ...]


def load_ohlcv(path: str | Path) -> pd.DataFrame:
    p = Path(path)
    if p.suffix.lower() == ".parquet":
        df = pd.read_parquet(p)
    elif p.suffix.lower() == ".csv":
        df = pd.read_csv(p)
    else:
        raise ValueError("Supported data formats are CSV and Parquet")

    date_col = next((c for c in df.columns if c.lower() in {"date", "datetime", "timestamp"}), None)
    if date_col is None:
        raise ValueError("Dataset must contain a Date, Datetime, or Timestamp column")

    df = df.rename(columns={date_col: "Date"})
    for col in REQUIRED:
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df["Date"] = pd.to_datetime(df["Date"], errors="coerce", utc=True)
    if df["Date"].isna().any():
        raise ValueError("Dataset contains invalid dates")

    df = df.sort_values("Date").drop_duplicates("Date").reset_index(drop=True)
    return df[["Date", *REQUIRED]]


def validate_ohlcv(df: pd.DataFrame) -> ValidationResult:
    issues: list[str] = []
    if df.empty:
        raise ValueError("Dataset is empty")
    if df[REQUIRED].isna().any().any():
        issues.append("missing_numeric_values")
    if (df["Close"] <= 0).any() or (df["Open"] <= 0).any():
        issues.append("non_positive_prices")
    if (df["High"] < df[["Open", "Close"]].max(axis=1)).any():
        issues.append("high_below_open_or_close")
    if (df["Low"] > df[["Open", "Close"]].min(axis=1)).any():
        issues.append("low_above_open_or_close")
    if (df["High"] < df["Low"]).any():
        issues.append("high_below_low")
    if (df["Volume"] < 0).any():
        issues.append("negative_volume")
    if df["Date"].duplicated().any():
        issues.append("duplicate_dates")

    if issues:
        raise ValueError("Data validation failed: " + ", ".join(issues))

    gaps = df["Date"].diff().dropna()
    warnings: list[str] = []
    if not gaps.empty and gaps.median().days > 0:
        unusual = gaps > gaps.median() * 5
        if unusual.any():
            warnings.append("large_date_gaps_detected")

    return ValidationResult(
        rows=len(df),
        start=df["Date"].iloc[0].date().isoformat(),
        end=df["Date"].iloc[-1].date().isoformat(),
        warnings=tuple(warnings),
    )
