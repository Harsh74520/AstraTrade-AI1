from __future__ import annotations
from dataclasses import dataclass
import pandas as pd
from .indicators import ema, rsi

@dataclass(frozen=True)
class StrategySpec:
    name: str
    params: dict


def signals_ema(df: pd.DataFrame, fast: int = 20, slow: int = 50) -> pd.Series:
    if fast >= slow:
        raise ValueError("fast EMA must be smaller than slow EMA")
    f = ema(df["Close"], fast)
    s = ema(df["Close"], slow)
    return (f > s).astype(int)


def signals_rsi(df: pd.DataFrame, period: int = 14, entry: float = 30, exit: float = 65) -> pd.Series:
    values = rsi(df["Close"], period)
    state = pd.Series(0, index=df.index, dtype=int)
    holding = False
    for i, value in enumerate(values):
        if not holding and value <= entry:
            holding = True
        elif holding and value >= exit:
            holding = False
        state.iloc[i] = int(holding)
    return state


def generate_signals(df: pd.DataFrame, spec: StrategySpec) -> pd.Series:
    name = spec.name.lower()
    if name == "ema":
        return signals_ema(df, **spec.params)
    if name == "rsi":
        return signals_rsi(df, **spec.params)
    raise ValueError(f"Unknown strategy: {spec.name}")
