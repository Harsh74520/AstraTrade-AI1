from __future__ import annotations
import argparse
import json
from .data import load_ohlcv, validate_ohlcv
from .engine import BacktestConfig, buy_and_hold, run_backtest
from .research import monte_carlo_trade_reshuffle, parameter_sweep, research_brief
from .strategies import StrategySpec, generate_signals


def build_parser():
    p=argparse.ArgumentParser(prog="astratrade", description="AI-assisted market research and backtesting")
    sub=p.add_subparsers(dest="command", required=True)
    v=sub.add_parser("validate"); v.add_argument("path")
    b=sub.add_parser("backtest"); b.add_argument("path"); b.add_argument("--strategy", choices=["ema","rsi"], default="ema")
    b.add_argument("--fast", type=int, default=20); b.add_argument("--slow", type=int, default=50)
    b.add_argument("--rsi-period", type=int, default=14); b.add_argument("--rsi-entry", type=float, default=30); b.add_argument("--rsi-exit", type=float, default=65)
    b.add_argument("--initial-capital", type=float, default=100000); b.add_argument("--fee-bps", type=float, default=5); b.add_argument("--slippage-bps", type=float, default=3)
    s=sub.add_parser("sweep"); s.add_argument("path"); s.add_argument("--strategy", choices=["ema"], default="ema"); s.add_argument("--fasts", default="10,20,30"); s.add_argument("--slows", default="50,80,100")
    a=sub.add_parser("api"); a.add_argument("--host",default="127.0.0.1"); a.add_argument("--port",type=int,default=8000)
    return p


def main():
    args=build_parser().parse_args()
    if args.command=="validate":
        result=validate_ohlcv(load_ohlcv(args.path)); print(json.dumps(result.__dict__,indent=2)); return
    if args.command=="backtest":
        df=load_ohlcv(args.path); validate_ohlcv(df)
        params=( {"fast":args.fast,"slow":args.slow} if args.strategy=="ema" else {"period":args.rsi_period,"entry":args.rsi_entry,"exit":args.rsi_exit})
        signal=generate_signals(df,StrategySpec(args.strategy,params))
        equity,trades,metrics=run_backtest(df,signal,BacktestConfig(args.initial_capital,args.fee_bps,args.slippage_bps))
        bench=buy_and_hold(df,args.initial_capital); bench_return=float(bench.iloc[-1]/bench.iloc[0]-1)
        mc=monte_carlo_trade_reshuffle(trades,args.initial_capital,iterations=500)
        out={"strategy":args.strategy,"params":params,"metrics":metrics,"benchmark_return":bench_return,"monte_carlo":mc,"research_brief":research_brief(metrics,bench_return,mc)}
        print(json.dumps(out,indent=2,default=str)); return
    if args.command=="sweep":
        df=load_ohlcv(args.path); validate_ohlcv(df)
        grid={"fast":[int(x) for x in args.fasts.split(",")],"slow":[int(x) for x in args.slows.split(",")]}
        rows=parameter_sweep(df,args.strategy,grid,BacktestConfig())
        print(json.dumps([r.__dict__ for r in rows],indent=2)); return
    if args.command=="api":
        import uvicorn
        uvicorn.run("astratrade.api:app",host=args.host,port=args.port,reload=False)
