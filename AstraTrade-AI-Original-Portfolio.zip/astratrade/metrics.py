from __future__ import annotations
import math
import numpy as np
import pandas as pd


def max_drawdown(equity: pd.Series) -> float:
    peak = equity.cummax()
    dd = equity / peak - 1
    return float(dd.min())


def performance_metrics(equity: pd.Series, trades: pd.DataFrame, initial_capital: float) -> dict:
    returns = equity.pct_change().dropna()
    days = max((equity.index[-1] - equity.index[0]).days, 1)
    years = days / 365.25
    total_return = float(equity.iloc[-1] / initial_capital - 1)
    cagr = float((equity.iloc[-1] / initial_capital) ** (1 / years) - 1) if equity.iloc[-1] > 0 else -1.0
    vol = float(returns.std(ddof=1) * np.sqrt(252)) if len(returns) > 1 else 0.0
    sharpe = float((returns.mean() / returns.std(ddof=1)) * np.sqrt(252)) if len(returns) > 1 and returns.std(ddof=1) > 0 else 0.0
    downside = returns[returns < 0].std(ddof=1)
    sortino = float((returns.mean() / downside) * np.sqrt(252)) if pd.notna(downside) and downside > 0 else 0.0

    if trades.empty:
        win_rate = profit_factor = 0.0
        trade_count = 0
    else:
        pnl = trades["pnl"]
        win_rate = float((pnl > 0).mean())
        gross_profit = float(pnl[pnl > 0].sum())
        gross_loss = float(-pnl[pnl < 0].sum())
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else math.inf
        trade_count = len(trades)

    return {
        "initial_capital": float(initial_capital),
        "ending_equity": float(equity.iloc[-1]),
        "total_return": total_return,
        "cagr": cagr,
        "annualized_volatility": vol,
        "sharpe": sharpe,
        "sortino": sortino,
        "max_drawdown": max_drawdown(equity),
        "trade_count": int(trade_count),
        "win_rate": win_rate,
        "profit_factor": profit_factor,
    }
