from __future__ import annotations
from dataclasses import dataclass
import pandas as pd
from .metrics import performance_metrics

@dataclass(frozen=True)
class BacktestConfig:
    initial_capital: float = 100_000.0
    fee_bps: float = 5.0
    slippage_bps: float = 3.0


def run_backtest(df: pd.DataFrame, signal: pd.Series, config: BacktestConfig):
    if len(df) != len(signal):
        raise ValueError("Signal length must match market data length")
    dates = pd.to_datetime(df["Date"])
    cash = config.initial_capital
    shares = 0.0
    entry_value = 0.0
    entry_date = None
    trades = []
    equity_values = []
    cost_rate = (config.fee_bps + config.slippage_bps) / 10_000

    for i, row in df.iterrows():
        price = float(row["Close"])
        desired = int(signal.iloc[i])
        if desired and shares == 0:
            invest = cash
            execution = price * (1 + config.slippage_bps / 10_000)
            fee = invest * config.fee_bps / 10_000
            shares = max((invest - fee) / execution, 0)
            cash = 0.0
            entry_value = shares * execution + fee
            entry_date = dates.iloc[i]
        elif not desired and shares > 0:
            execution = price * (1 - config.slippage_bps / 10_000)
            gross = shares * execution
            fee = gross * config.fee_bps / 10_000
            proceeds = gross - fee
            pnl = proceeds - entry_value
            trades.append({"entry_date": entry_date, "exit_date": dates.iloc[i], "entry_price": entry_value / shares, "exit_price": execution, "pnl": pnl})
            cash = proceeds
            shares = 0.0
            entry_value = 0.0
            entry_date = None
        equity_values.append(cash + shares * price)

    if shares > 0:
        price = float(df["Close"].iloc[-1])
        execution = price * (1 - config.slippage_bps / 10_000)
        gross = shares * execution
        fee = gross * config.fee_bps / 10_000
        proceeds = gross - fee
        pnl = proceeds - entry_value
        trades.append({"entry_date": entry_date, "exit_date": dates.iloc[-1], "entry_price": entry_value / shares, "exit_price": execution, "pnl": pnl})
        cash = proceeds
        shares = 0.0
        equity_values[-1] = cash

    equity = pd.Series(equity_values, index=dates, name="equity")
    trade_df = pd.DataFrame(trades)
    metrics = performance_metrics(equity, trade_df, config.initial_capital)
    return equity, trade_df, metrics


def buy_and_hold(df: pd.DataFrame, initial_capital: float) -> pd.Series:
    prices = df["Close"].astype(float)
    shares = initial_capital / float(prices.iloc[0])
    return prices * shares
