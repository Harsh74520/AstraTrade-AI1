from __future__ import annotations
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from .data import load_ohlcv, validate_ohlcv
from .engine import BacktestConfig, buy_and_hold, run_backtest
from .strategies import StrategySpec, generate_signals
from .research import research_brief, monte_carlo_trade_reshuffle

app=FastAPI(title="AstraTrade AI", version="0.1.0")

class BacktestRequest(BaseModel):
    path: str
    strategy: str = "ema"
    params: dict = Field(default_factory=lambda: {"fast":20,"slow":50})
    initial_capital: float = 100000
    fee_bps: float = 5
    slippage_bps: float = 3

@app.get("/health")
def health():
    return {"status":"ok","service":"astratrade-ai"}

@app.post("/validate")
def validate(path: str):
    try:
        df=load_ohlcv(path); result=validate_ohlcv(df)
        return result.__dict__
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

@app.post("/backtest")
def backtest(req: BacktestRequest):
    try:
        df=load_ohlcv(req.path); validate_ohlcv(df)
        spec=StrategySpec(req.strategy, req.params)
        signal=generate_signals(df, spec)
        cfg=BacktestConfig(req.initial_capital, req.fee_bps, req.slippage_bps)
        equity,trades,metrics=run_backtest(df,signal,cfg)
        benchmark=buy_and_hold(df,req.initial_capital)
        bench_return=float(benchmark.iloc[-1]/benchmark.iloc[0]-1)
        mc=monte_carlo_trade_reshuffle(trades,req.initial_capital,iterations=500)
        return {"metrics":metrics,"benchmark_return":bench_return,"research_brief":research_brief(metrics,bench_return,mc),"trade_count":len(trades)}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
