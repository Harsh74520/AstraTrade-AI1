from __future__ import annotations
import os

SYSTEM = "You are a cautious quantitative research assistant. Summarize supplied backtest metrics only. Never invent data, never imply guaranteed returns, and clearly distinguish simulation from prediction."


def summarize_with_llm(metrics: dict, benchmark_return: float, model: str | None = None) -> str:
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        raise RuntimeError("OPENAI_API_KEY is not configured; use the deterministic research_brief function instead")
    try:
        from openai import OpenAI
    except ImportError as exc:
        raise RuntimeError("Install the optional 'llm' extra to use LLM summaries") from exc

    client=OpenAI(api_key=key, base_url=os.getenv("ASTRATRADE_LLM_BASE_URL"))
    model=model or os.getenv("ASTRATRADE_LLM_MODEL", "gpt-4.1-mini")
    payload={**metrics, "benchmark_return": benchmark_return}
    response=client.chat.completions.create(
        model=model,
        temperature=0,
        messages=[
            {"role":"system","content":SYSTEM},
            {"role":"user","content":f"Summarize these computed results for a research log:\n{payload}"},
        ],
    )
    return response.choices[0].message.content or "No summary returned."
