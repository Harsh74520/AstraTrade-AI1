# Security

AstraTrade AI is intended for local research and simulation. Do not store API keys or account credentials in the repository. Keep `.env` files out of Git. The project does not implement live order placement.

For a suspected vulnerability, open a private security report with the repository maintainer rather than publishing credentials or sensitive data in a public issue.
