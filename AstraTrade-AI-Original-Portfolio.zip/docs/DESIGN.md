# Design notes

## Research-first execution

AstraTrade separates deterministic computation from optional language-model narration. Data validation, signals, execution simulation, metrics, benchmark calculations, and Monte Carlo analysis are all computed locally.

## Execution model

The simulator supports one long position at a time. Entry and exit happen at the bar Close with configurable slippage and transaction fees. No broker order is created.

## Extending the toolkit

Implement a new strategy in `astratrade/strategies.py`, then register it in `generate_signals` and expose parameters in the CLI/API layer. More sophisticated portfolio models can be added without changing the data-validation or reporting interfaces.
