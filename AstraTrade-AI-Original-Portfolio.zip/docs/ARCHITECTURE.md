# Architecture

```mermaid
flowchart LR
  A[CSV / Parquet] --> B[Data validation]
  B --> C[Indicator layer]
  C --> D[Strategy signals]
  D --> E[Portfolio simulator]
  E --> F[Trade ledger]
  E --> G[Equity curve]
  F --> H[Risk + performance metrics]
  G --> H
  H --> I[Benchmark comparison]
  H --> J[Monte Carlo robustness]
  H --> K[Deterministic research brief]
  H -. optional .-> L[LLM narrator]
```

The core path is deterministic. The optional LLM component can narrate already-computed metrics but does not supply prices, fabricate results, or execute trades.
