import pandas as pd
from astratrade.data import load_ohlcv, validate_ohlcv
from astratrade.engine import BacktestConfig, run_backtest
from astratrade.strategies import StrategySpec, generate_signals


def test_sample_data_valid():
    df=load_ohlcv("examples/sample_data.csv")
    result=validate_ohlcv(df)
    assert result.rows == 22


def test_ema_backtest_runs():
    df=load_ohlcv("examples/sample_data.csv")
    sig=generate_signals(df,StrategySpec("ema",{"fast":3,"slow":5}))
    equity,trades,metrics=run_backtest(df,sig,BacktestConfig())
    assert len(equity)==len(df)
    assert metrics["initial_capital"]==100000
    assert metrics["ending_equity"]>0


def test_invalid_ohlc_rejected():
    df=pd.DataFrame({"Date":pd.to_datetime(["2025-01-01"]),"Open":[10],"High":[9],"Low":[11],"Close":[10],"Volume":[1]})
    try:
        validate_ohlcv(df)
    except ValueError as exc:
        assert "high_below_open_or_close" in str(exc)
    else:
        raise AssertionError("Expected validation failure")
