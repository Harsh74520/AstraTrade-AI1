# Contributing

Keep research computations deterministic and separate from optional LLM narration. New strategies should include tests and should document assumptions about price timing, fees, slippage, and position sizing.

Do not add broker order-placement code without a separate security and risk review. Avoid committing API keys, account data, or private datasets.
